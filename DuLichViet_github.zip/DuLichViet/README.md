# 🌤️ Mây Việt – Website đặt tour du lịch

Đồ án môn PHP · mô hình **MVC thuần (OOP)** · PHP + MySQL (PDO) + Bootstrap 5.
Giao diện **xanh – trắng**, có chuyển động mượt, tối ưu SEO và nhiều tính năng giữ chân khách hàng.

## ✨ Tính năng

**Khách hàng**
- Xem/tìm/lọc tour, chi tiết tour, đánh giá, yêu thích, giỏ tour, đặt tour, theo dõi & huỷ đơn
- Mã giảm giá (voucher) khi đặt tour
- **Ưu đãi cá nhân hoá**: xem tour ở điểm đến nào → nhận mã giảm giá của điểm đến đó
- **Mini-game lật thẻ** (Free-to-play & Play-to-earn): chơi sau khi đặt tour để nhận voucher; 3 cấp độ, 2 lượt/đơn, vòng quay quà ở cấp Khó
- **Cây thành tích**: đặt tour càng nhiều, cây càng lớn (Mầm non → Chồi non → Cành lá → Cây thành tựu), mỗi cấp mở một quà
- **Bảng xếp hạng**: người đặt tour nhiều nhất & người có điểm mini-game cao nhất (lọc theo tuần/tháng/mọi lúc)
- **Hạng thành viên**: Explorer / Traveler / Globetrotter, hệ số điểm x1 / x1,5 / x2
- Cẩm nang du lịch chuẩn SEO (meta, Open Graph, JSON-LD, sitemap)
- Nút hỗ trợ 24/7 (hotline, Zalo, Messenger)

**Quản trị (admin)**
- Quản lý tour, danh mục, đơn hàng, voucher, người dùng, đánh giá, thống kê

## 🛠️ Yêu cầu
- XAMPP / Laragon (PHP **8.0+**, bật extension `pdo_mysql`, `mbstring`) và MySQL/MariaDB
- Có Internet (Bootstrap, font, một số ảnh lấy từ CDN)

## 🚀 Cài đặt nhanh
1. Chép thư mục dự án vào `C:\xampp\htdocs\DuLichViet` (hoặc tải về bằng `git clone`).
2. Bật **Apache** và **MySQL** trong XAMPP.
3. Tạo cấu hình: sao chép `configs/env.example.php` thành `configs/env.php`, rồi chỉnh:
   - `BASE_URL` (ví dụ `http://localhost/DuLichViet/`)
   - `DB_PASSWORD` nếu MySQL của bạn có mật khẩu.
4. Import database: mở phpMyAdmin → tab **Import** → chọn `database/du_lich_viet.sql`.
5. (Tuỳ chọn) Import `database/du_lieu_mau_xep_hang.sql` để bảng xếp hạng có dữ liệu demo.
6. Mở trình duyệt: <http://localhost/DuLichViet/>

## 🔑 Tài khoản demo
| Vai trò | Email | Mật khẩu |
|---|---|---|
| Admin | `admin@gmail.com` | `123456` |
| Khách hàng | `khachhang@gmail.com` | `123456` |

> Chỉ dùng cho mục đích học tập. Hãy đổi mật khẩu nếu triển khai thật.

## 📁 Cấu trúc
```
DuLichViet/
├── index.php            # điểm vào, tự load class
├── routes/              # điều hướng ?action=...
├── controllers/         # xử lý nghiệp vụ
├── models/              # truy vấn database (PDO)
├── views/               # giao diện (client, admin, auth)
├── configs/             # env.example.php, helper.php, cam_nang.php
├── assets/              # css, js, img, uploads
├── database/            # file .sql
└── docs/                # các tài liệu hướng dẫn chi tiết
```

## 🖼️ Ảnh
Ảnh tour ưu tiên file trong `assets/img/` (ví dụ `tour-ha-long.jpg`); nếu không có sẽ dùng ảnh trên mạng và tự chuyển sang ảnh dự phòng khi lỗi. Chi tiết: `docs/HUONG_DAN_SUA_ANH_BI_TRONG.txt`.

## 📝 Ghi chú
Dự án phục vụ học tập. Ảnh minh hoạ thuộc về chủ sở hữu tương ứng.
