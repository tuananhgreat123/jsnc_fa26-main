<?php

// Khởi động session
session_start();

// Tự động load class Model và Controller
spl_autoload_register(function ($ten_class) {
    $ten_file = "$ten_class.php";

    $duong_dan_model      = PATH_MODEL . $ten_file;
    $duong_dan_controller = PATH_CONTROLLER . $ten_file;

    if (is_readable($duong_dan_model)) {
        require_once $duong_dan_model;
    } elseif (is_readable($duong_dan_controller)) {
        require_once $duong_dan_controller;
    }
});

// Load cấu hình (file env.php không đưa lên GitHub – hãy sao chép từ env.example.php)
if (!file_exists(__DIR__ . '/configs/env.php')) {
    http_response_code(500);
    exit('<meta charset="UTF-8"><h3>Chưa có file cấu hình</h3><p>Hãy sao chép <code>configs/env.example.php</code> thành <code>configs/env.php</code> rồi chỉnh BASE_URL và thông tin MySQL.</p>');
}
require_once './configs/env.php';
require_once './configs/helper.php';

// Điều hướng URL
require_once './routes/index.php';
